package com.example.qingtingwidgetdemo;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Implementation of App Widget functionality.
 */
public class PlayerWidget extends AppWidgetProvider {

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId, Intent intent) {

        // Construct the RemoteViews object
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.player_widget);
        views.setOnClickPendingIntent(R.id.tv_previous, PendingIntent.getBroadcast(context, 0, new Intent("com.tencent.qqmusicsdk.ACTION_SERVICE_PREVIOUS_TASKBAR"), 0));
        views.setOnClickPendingIntent(R.id.tv_playpause, PendingIntent.getBroadcast(context, 0, new Intent("com.tencent.qqmusicsdk.ACTION_SERVICE_TOGGLEPAUSE_TASKBAR"), 0));
        views.setOnClickPendingIntent(R.id.tv_next, PendingIntent.getBroadcast(context, 0, new Intent("com.tencent.qqmusicsdk.ACTION_SERVICE_NEXT_TASKBAR"), 0));
        //set music information
        if(intent != null){
            String song = intent.getStringExtra(MusicService.TRACK);
            String singer = intent.getStringExtra(MusicService.ARTIST);
            String album = intent.getStringExtra(MusicService.ALBUM);
            views.setTextViewText(R.id.tv_song, song);
            views.setTextViewText(R.id.tv_singer, singer);
            views.setTextViewText(R.id.tv_album, album);
        }
        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        onUpdate(context, appWidgetManager, appWidgetIds, null);
    }

    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds, Intent intent){
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId, intent);
        }
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        if(MusicService.OMMIAO.equals(intent.getStringExtra(MusicService.OMMIAO))){
            onUpdate(context, AppWidgetManager.getInstance(context), AppWidgetManager.getInstance(context).getAppWidgetIds(new ComponentName(context, PlayerWidget.class)), intent);
        } else {
            super.onReceive(context, intent);
        }
    }

}

